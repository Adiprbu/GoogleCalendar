﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Microsoft.AppCenter;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using System.Globalization;


namespace Calendar
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static async System.Threading.Tasks.Task Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            AppCenter.Start("61ba65dc-cd87-4bea-aa59-0ab21a6bc5e2",
                   typeof(Analytics), typeof(Crashes));

            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.ThrowException);
            AppCenter.Start();

            Application.ThreadException += (sender, args) =>
            {
                Crashes.TrackError(args.Exception);
            };
            AppCenter.Start();

            bool didAppCrash = await Crashes.HasCrashedInLastSessionAsync();

            ErrorReport crashReport = await Crashes.GetLastSessionCrashReportAsync();

            // Depending on the user's choice, call Crashes.NotifyUserConfirmation() with the right value.
            Crashes.NotifyUserConfirmation(UserConfirmation.DontSend);
            Crashes.NotifyUserConfirmation(UserConfirmation.Send);
            Crashes.NotifyUserConfirmation(UserConfirmation.AlwaysSend);

            try
            {
            }
            catch (Exception exception)
            {
                var properties = new Dictionary<string, string>
    {
        { "Category", "Music" },
        { "Wifi", "On"}
    };
                Crashes.TrackError(exception, properties);
            }

            Application.Run(new Calendar());
        }

        private static void SetCountryCode()
        {
            var countryCode = RegionInfo.CurrentRegion.TwoLetterISORegionName;
            AppCenter.SetCountryCode(countryCode);
        }
    }
}
