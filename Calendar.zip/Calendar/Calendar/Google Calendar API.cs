﻿using System;
using System.Windows.Forms;
using System.Diagnostics;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Calendar.v3;
using Google.Apis.Calendar.v3.Data;
using Google.Apis.Services;
using Google.Apis.Util.Store;
using System.IO;
using System.Threading;

namespace Calendar
{
    public partial class Calendar : Form
    {
        static string[] Scopes = { CalendarService.Scope.CalendarReadonly };
        static string ApplicationName = "Google Calendar API .NET Quickstart";

        public Calendar()
        {
            InitializeComponent();
            GoogleAPI();
        }

        private void GoogleAPI()
        {
            UserCredential credential;

            using (var stream =
                new FileStream("credentials.json", FileMode.Open, FileAccess.Read))
            {
                // The file token.json stores the user's access and refresh tokens, and is created
                // automatically when the authorization flow completes for the first time.
                string credPath = "token.json";
                credential = GoogleWebAuthorizationBroker.AuthorizeAsync(
                    GoogleClientSecrets.Load(stream).Secrets,
                    Scopes,
                    "user",
                    CancellationToken.None,
                    new FileDataStore(credPath, true)).Result;
            }

            // Create Google Calendar API service.
            var service = new CalendarService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = ApplicationName,
            });

            // Define parameters of request.
            EventsResource.ListRequest request = service.Events.List("primary");
            request.TimeMin = DateTime.Now;
            request.ShowDeleted = false;
            request.SingleEvents = true;
            request.MaxResults = 5;
            request.OrderBy = EventsResource.ListRequest.OrderByEnum.StartTime;

            // List events.
            Events events = request.Execute();
            if (events.Items != null && events.Items.Count > 0)
            {
                CalendarEvents.Text = "";
                foreach (var eventItem in events.Items)
                {
                    CalendarEvents.Text += eventItem.Summary + Environment.NewLine;
                }
            }
            else
            {
                CalendarEvents.Text = "No Upcoming Events";
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            timeToolStripMenuItem.Text = "Time : " + DateTime.Now.ToLongTimeString();
        }

        private void Calendar_Load(object sender, EventArgs e)
        {
            dateToolStripMenuItem.Text = "Date : " + DateTime.Now.ToLongDateString();
            Timer.Start();
        }

        private void myWebsiteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://feedbackadiprbu.wixsite.com/website");
        }

        private void designedByAdityaSPrabhuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://feedbackadiprbu.wixsite.com/website/about");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure You Want To Exit?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }

            else
            {
                ActiveForm.Show();
            } 
        }

        private void EventTimer_Tick(object sender, EventArgs e)
        {
            GoogleAPI();
        }

        private void createdInVisualStudioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://en.wikipedia.org/wiki/Microsoft_Visual_Studio");
        }

        private void winformsCNETToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://en.wikipedia.org/wiki/Windows_Forms");
            Process.Start("https://en.wikipedia.org/wiki/.NET_Framework");
        }

        private void googleCalendarAPIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://en.wikipedia.org/wiki/Google_Calendar");
        }
    }
}
