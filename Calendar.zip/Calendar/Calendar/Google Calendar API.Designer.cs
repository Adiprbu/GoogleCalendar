﻿
namespace Calendar
{
    partial class Calendar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MenuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.myWebsiteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.createdInVisualStudioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.winformsCNETToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.googleCalendarAPIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.designedByAdityaSPrabhuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.dateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Timer = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.CalendarEvents = new System.Windows.Forms.Label();
            this.EventTimer = new System.Windows.Forms.Timer(this.components);
            this.MenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // MenuStrip
            // 
            this.MenuStrip.Font = new System.Drawing.Font("Segoe Script", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.aboutToolStripMenuItem,
            this.dateToolStripMenuItem,
            this.timeToolStripMenuItem});
            this.MenuStrip.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip.Name = "MenuStrip";
            this.MenuStrip.Size = new System.Drawing.Size(725, 31);
            this.MenuStrip.TabIndex = 3;
            this.MenuStrip.Text = "MenuStrip";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(50, 27);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(111, 28);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.myWebsiteToolStripMenuItem,
            this.toolStripSeparator2,
            this.createdInVisualStudioToolStripMenuItem,
            this.toolStripSeparator3,
            this.winformsCNETToolStripMenuItem,
            this.toolStripSeparator4,
            this.googleCalendarAPIToolStripMenuItem,
            this.toolStripSeparator6,
            this.designedByAdityaSPrabhuToolStripMenuItem,
            this.toolStripSeparator5});
            this.aboutToolStripMenuItem.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(67, 27);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // myWebsiteToolStripMenuItem
            // 
            this.myWebsiteToolStripMenuItem.Name = "myWebsiteToolStripMenuItem";
            this.myWebsiteToolStripMenuItem.Size = new System.Drawing.Size(305, 28);
            this.myWebsiteToolStripMenuItem.Text = "My Website";
            this.myWebsiteToolStripMenuItem.Click += new System.EventHandler(this.myWebsiteToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(302, 6);
            // 
            // createdInVisualStudioToolStripMenuItem
            // 
            this.createdInVisualStudioToolStripMenuItem.Name = "createdInVisualStudioToolStripMenuItem";
            this.createdInVisualStudioToolStripMenuItem.Size = new System.Drawing.Size(305, 28);
            this.createdInVisualStudioToolStripMenuItem.Text = "Created In Visual Studio";
            this.createdInVisualStudioToolStripMenuItem.Click += new System.EventHandler(this.createdInVisualStudioToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(302, 6);
            // 
            // winformsCNETToolStripMenuItem
            // 
            this.winformsCNETToolStripMenuItem.Name = "winformsCNETToolStripMenuItem";
            this.winformsCNETToolStripMenuItem.Size = new System.Drawing.Size(305, 28);
            this.winformsCNETToolStripMenuItem.Text = "Winforms C# .NET";
            this.winformsCNETToolStripMenuItem.Click += new System.EventHandler(this.winformsCNETToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(302, 6);
            // 
            // googleCalendarAPIToolStripMenuItem
            // 
            this.googleCalendarAPIToolStripMenuItem.Name = "googleCalendarAPIToolStripMenuItem";
            this.googleCalendarAPIToolStripMenuItem.Size = new System.Drawing.Size(305, 28);
            this.googleCalendarAPIToolStripMenuItem.Text = "Google Calendar API";
            this.googleCalendarAPIToolStripMenuItem.Click += new System.EventHandler(this.googleCalendarAPIToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(302, 6);
            // 
            // designedByAdityaSPrabhuToolStripMenuItem
            // 
            this.designedByAdityaSPrabhuToolStripMenuItem.Name = "designedByAdityaSPrabhuToolStripMenuItem";
            this.designedByAdityaSPrabhuToolStripMenuItem.Size = new System.Drawing.Size(305, 28);
            this.designedByAdityaSPrabhuToolStripMenuItem.Text = "Designed By : Aditya S Prabhu";
            this.designedByAdityaSPrabhuToolStripMenuItem.Click += new System.EventHandler(this.designedByAdityaSPrabhuToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(302, 6);
            // 
            // dateToolStripMenuItem
            // 
            this.dateToolStripMenuItem.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateToolStripMenuItem.Name = "dateToolStripMenuItem";
            this.dateToolStripMenuItem.Size = new System.Drawing.Size(57, 27);
            this.dateToolStripMenuItem.Text = "Date";
            // 
            // timeToolStripMenuItem
            // 
            this.timeToolStripMenuItem.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timeToolStripMenuItem.Name = "timeToolStripMenuItem";
            this.timeToolStripMenuItem.Size = new System.Drawing.Size(57, 27);
            this.timeToolStripMenuItem.Text = "Time";
            // 
            // Timer
            // 
            this.Timer.Tick += new System.EventHandler(this.Timer_Tick);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(725, 124);
            this.label1.TabIndex = 4;
            this.label1.Text = "Upcoming Events";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CalendarEvents
            // 
            this.CalendarEvents.BackColor = System.Drawing.Color.Transparent;
            this.CalendarEvents.Dock = System.Windows.Forms.DockStyle.Top;
            this.CalendarEvents.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalendarEvents.Location = new System.Drawing.Point(0, 155);
            this.CalendarEvents.Name = "CalendarEvents";
            this.CalendarEvents.Size = new System.Drawing.Size(725, 281);
            this.CalendarEvents.TabIndex = 5;
            this.CalendarEvents.Text = "Upcoming Events";
            this.CalendarEvents.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // EventTimer
            // 
            this.EventTimer.Enabled = true;
            this.EventTimer.Interval = 10000;
            this.EventTimer.Tick += new System.EventHandler(this.EventTimer_Tick);
            // 
            // Calendar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tan;
            this.ClientSize = new System.Drawing.Size(725, 445);
            this.Controls.Add(this.CalendarEvents);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.MenuStrip);
            this.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Calendar";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Google Calendar API | Home";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Calendar_Load);
            this.MenuStrip.ResumeLayout(false);
            this.MenuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MenuStrip;
        private System.Windows.Forms.ToolStripMenuItem dateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem timeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem myWebsiteToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem createdInVisualStudioToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem designedByAdityaSPrabhuToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.Timer Timer;
        private System.Windows.Forms.ToolStripMenuItem winformsCNETToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label CalendarEvents;
        private System.Windows.Forms.Timer EventTimer;
        private System.Windows.Forms.ToolStripMenuItem googleCalendarAPIToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
    }
}

